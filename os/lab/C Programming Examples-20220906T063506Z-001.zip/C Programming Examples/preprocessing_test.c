#include <stdio.h>
#define message "Hello, World!\n"

int main()
{
	printf(message);
	return 0;
}
