#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	int N;
	printf("argv[0] = %s\n", argv[0]);
	if(argc == 1) {
		printf("No command line arguments passed. Setting N to 10.\n");
		N = 10;
	}
	else {
		printf("argv[1] = %s\n", argv[1]);
		N = atoi(argv[1]);
	}
	int *ptr = (int*) malloc(N*sizeof(int));
	if(ptr == NULL) {
		printf("Memory not available.\n");
		exit(1);
	}

	*ptr = 0;
	*(ptr + 1) = 1;

	for(int i = 2; i < N; i++)
		*(ptr + i) = *(ptr + (i-1)) + *(ptr + (i-2));

	for(int i = 0; i < N; i++)
		printf("%d ", *(ptr + i));

	printf("\n");
	printf("ptr[1] before free: %d\n", *(ptr + 1));
	printf("ptr before free: %p\n", ptr);
	
	free(ptr);
	//ptr = NULL;
	
	printf("ptr[1] after free: %d\n", *(ptr + 1));
	printf("ptr after free: %p\n", ptr);
	return 0;
}
