#include<stdio.h>
#define MAX_SIZE 2

void subtract(int *first, int *second, int *result)
{
	for(int i=0;i<MAX_SIZE; i++) // compute the differences
	{
		result[i] = second[i] - first[i];
	}
}

void print_arr(int *arr)
{
	for(int i=0;i<MAX_SIZE; i++) // output the arrays
	{
		printf("%d ", arr[i]);
	}
	printf("\n");
}

void main()
{
	int first[MAX_SIZE], second[MAX_SIZE], diff[MAX_SIZE], i;
	printf("\nEnter %d data items for first array : ", MAX_SIZE);
	for(i=0;i<MAX_SIZE; i++) // input first array
	{ // input first aaray
		scanf("%d", &first[i] );
	}
	printf("\nEnter %d data items for second array : ", MAX_SIZE);
	for(i=0;i<MAX_SIZE; i++) // input second array
	{
		scanf("%d",&second[i]);
	}
	
	subtract(first, second, diff);
	printf("result: ");
	print_arr(diff);

}
