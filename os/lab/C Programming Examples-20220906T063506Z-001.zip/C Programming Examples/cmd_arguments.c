#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[])
{
	for(int c = 0; c < argc; c++) {
			printf("argv[%d] = %s\n", c, argv[c]);
	}
	
	if(argc < 4)
	{
		printf("You must input three numbers as command line inputs. \n");
		exit(0);
	}
	int sum;
	sum = atoi(argv[1]) + atoi(argv[2]) + atoi(argv[3]);
	printf("argv[0] is = <%s>\n", argv[0]);
	printf("The sum of three values is = %d\n", sum);
}
