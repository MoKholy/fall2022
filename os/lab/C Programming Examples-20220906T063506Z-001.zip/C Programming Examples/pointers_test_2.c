#include <stdio.h>
int main() {
	int i1, i2, *p1, *p2;
	i1 = 5;
	p1 = &i1;
	printf("p1 = %p, p2 = %p\n", p1, p2);
	i2 = *p1 / 2 + 10;
	p2 = p1;
	printf("i1 = %d, i2 = %d, *p1 = %d, *p2 = %d, p1 = %p, p2 = %p\n", i1, i2, *p1, *p2, (void *) p1, (void *) p2);
	return 0;
}
